-- IDE FLOW v2: AI idea workflow
create table if not exists public.idea_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  raw_idea text not null,
  category text not null default 'Aplikasi',
  goal text not null default '',
  target_users text not null default '',
  features text not null default '',
  platform text not null default '',
  expected_output text not null default '',
  status text not null default 'draft' check (status in ('draft','clarified','prompt_ready','completed','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.idea_prompt_versions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.idea_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null check (mode in ('short','detail','master')),
  prompt text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.idea_clarification_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.idea_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_idea_projects_user_updated on public.idea_projects(user_id, updated_at desc);
create index if not exists idx_idea_prompts_project on public.idea_prompt_versions(project_id, created_at desc);
create index if not exists idx_idea_messages_project on public.idea_clarification_messages(project_id, created_at asc);
alter table public.idea_projects enable row level security;
alter table public.idea_prompt_versions enable row level security;
alter table public.idea_clarification_messages enable row level security;
create policy "idea_projects_select_own" on public.idea_projects for select to authenticated using ((select auth.uid()) = user_id);
create policy "idea_projects_insert_own" on public.idea_projects for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "idea_projects_update_own" on public.idea_projects for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "idea_projects_delete_own" on public.idea_projects for delete to authenticated using ((select auth.uid()) = user_id);
create policy "idea_prompts_select_own" on public.idea_prompt_versions for select to authenticated using ((select auth.uid()) = user_id);
create policy "idea_prompts_insert_own" on public.idea_prompt_versions for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "idea_prompts_delete_own" on public.idea_prompt_versions for delete to authenticated using ((select auth.uid()) = user_id);
create policy "idea_messages_select_own" on public.idea_clarification_messages for select to authenticated using ((select auth.uid()) = user_id);
create policy "idea_messages_insert_own" on public.idea_clarification_messages for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "idea_messages_delete_own" on public.idea_clarification_messages for delete to authenticated using ((select auth.uid()) = user_id);
create or replace function public.set_idea_projects_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger idea_projects_updated_at before update on public.idea_projects
for each row execute function public.set_idea_projects_updated_at();

-- Least-privilege Data API grants for the Android client.
revoke all on table public.idea_projects from anon;
revoke all on table public.idea_prompt_versions from anon;
revoke all on table public.idea_clarification_messages from anon;
revoke all on table public.idea_projects from authenticated;
revoke all on table public.idea_prompt_versions from authenticated;
revoke all on table public.idea_clarification_messages from authenticated;
grant select, insert, update, delete on table public.idea_projects to authenticated;
grant select, insert, delete on table public.idea_prompt_versions to authenticated;
grant select, insert, delete on table public.idea_clarification_messages to authenticated;
