# IDE FLOW Supabase backend

Supabase project: Rofat.

The database tables are:
- idea_projects
- idea_clarification_messages
- idea_prompt_versions

The Edge Function is `ideaflow-ai`.

Before live AI calls, configure Supabase Function secrets:
- `OPENAI_API_KEY`
- optional `OPENAI_MODEL`
- optional `OPENAI_BASE_URL`

The API key must remain server-side. Do not put it in the Android APK.
