import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

const system = `
You are IDE FLOW, an idea clarification and prompt-generation engine.
Your job is to turn messy user ideas into clear, implementation-ready project specifications.
Rules:
- Preserve the user's original intent.
- Do not invent unnecessary features.
- Ask only questions that materially affect the project.
- If enough information exists, produce a blueprint without asking more.
- Use concise Indonesian.
- For clarification, return ONLY valid JSON:
{
  "action": "ask" | "blueprint",
  "questions": ["..."],
  "blueprint": {
    "title": "...",
    "goal": "...",
    "target_users": "...",
    "platform": "...",
    "features": ["..."],
    "expected_output": "...",
    "assumptions": ["..."]
  }
}
`;

function fallbackBlueprint(raw: string) {
  return {
    action: "blueprint",
    questions: [],
    blueprint: {
      title: "Proyek Baru",
      goal: raw,
      target_users: "Pengguna yang membutuhkan solusi tersebut",
      platform: "Android",
      features: [],
      expected_output: "Produk yang siap dikembangkan",
      assumptions: ["Detail teknis akan ditentukan setelah kebutuhan utama dikonfirmasi."]
    }
  };
}

async function callAI(messages: Array<{role:string;content:string}>) {
  const key = Deno.env.get("OPENAI_API_KEY");
  if (!key) throw new Error("OPENAI_API_KEY belum dikonfigurasi di Supabase Secrets.");

  const base = (Deno.env.get("OPENAI_BASE_URL") || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = Deno.env.get("OPENAI_MODEL") || "gpt-4o-mini";

  const response = await fetch(base + "/chat/completions", {
    method: "POST",
    headers: {"Authorization": "Bearer " + key, "Content-Type": "application/json"},
    body: JSON.stringify({model, temperature: 0.2, messages})
  });
  if (!response.ok) throw new Error("AI provider error: " + (await response.text()).slice(0, 500));
  const data = await response.json();
  return data?.choices?.[0]?.message?.content || "";
}

function extractJSON(text: string) {
  const cleaned = text.trim().replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/\s*```$/i, "");
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf("{"), end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) { try { return JSON.parse(cleaned.slice(start, end + 1)); } catch {} }
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", {headers: cors});
  try {
    const body = await req.json();
    const action = body?.action;
    const idea = body?.idea;
    if (!idea || typeof idea.raw_idea !== "string") return json({error:"idea.raw_idea wajib diisi."},400);

    if (action === "clarify") {
      const history = Array.isArray(body.history) ? body.history : [];
      const prompt = [
        "IDE MENTAH:", idea.raw_idea,
        "", "DATA YANG SUDAH DIKETAHUI:", JSON.stringify(idea),
        "", "RIWAYAT KLARIFIKASI:", JSON.stringify(history),
        "", "Tentukan apakah perlu bertanya lagi. Jika ya, buat maksimal 4 pertanyaan paling penting. Jika tidak, buat blueprint final."
      ].join("\n");
      const raw = await callAI([{role:"system",content:system},{role:"user",content:prompt}]);
      return json(extractJSON(raw) || fallbackBlueprint(idea.raw_idea));
    }

    if (action === "prompt") {
      const mode = body?.mode || "master";
      const blueprint = body?.blueprint || idea;
      const instructions: Record<string,string> = {
        short:"Buat prompt sangat singkat tetapi cukup jelas untuk AI developer.",
        detail:"Buat prompt detail berisi tujuan, pengguna, fitur, platform, UX, data, dan langkah implementasi.",
        master:"Buat master prompt profesional dengan role AI, konteks proyek, requirement, arsitektur, UX, data model, keamanan, tahapan implementasi, testing, dan aturan agar AI tidak mengarang kebutuhan."
      };
      const raw = await callAI([
        {role:"system",content:"Anda adalah prompt engineer profesional. Gunakan bahasa Indonesia. Hasil akhir harus berupa prompt siap copy, tanpa penjelasan tambahan."},
        {role:"user",content:(instructions[mode] || instructions.master) + "\n\nBLUEPRINT:\n" + JSON.stringify(blueprint) + "\n\nIDE ASLI:\n" + idea.raw_idea}
      ]);
      return json({mode,prompt:raw.trim()});
    }
    return json({error:"action harus clarify atau prompt."},400);
  } catch (e) {
    return json({error:e instanceof Error ? e.message : "Terjadi kesalahan."},500);
  }
});