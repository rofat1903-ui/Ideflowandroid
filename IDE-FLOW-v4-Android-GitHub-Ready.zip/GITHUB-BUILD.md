# Build IDE FLOW APK dari HP memakai GitHub Actions

## 1. Upload project
Upload seluruh isi folder ini ke repository GitHub.

Struktur utama:

- `.github/workflows/build-apk.yml` — otomatis build APK
- `app/` — aplikasi Android
- `supabase/` — migration dan Edge Function
- `build.gradle.kts`
- `settings.gradle.kts`

## 2. Jalankan build

Setelah file masuk ke branch `main`:

1. Buka repository di GitHub.
2. Pilih tab **Actions**.
3. Pilih workflow **Build IDE FLOW APK**.
4. Tekan **Run workflow**.
5. Tunggu sampai status berubah menjadi hijau.

Workflow juga otomatis berjalan setiap kali ada push ke `main`.

## 3. Download APK

Buka hasil workflow yang sudah selesai.
Cari bagian **Artifacts**.
Download:

`IDE-FLOW-debug-apk`

ZIP artifact tersebut berisi file APK. Ekstrak di HP lalu install APK.

## Catatan

- Build ini adalah **debug APK** untuk testing.
- Supabase URL dan publishable key adalah konfigurasi client. Jangan pernah memasukkan `service_role` atau secret AI ke aplikasi.
- `OPENAI_API_KEY` harus tetap berada di Supabase Edge Function `ideaflow-ai` sebagai secret.
