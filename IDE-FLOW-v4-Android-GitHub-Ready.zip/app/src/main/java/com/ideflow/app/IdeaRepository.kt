package com.ideflow.app

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.Serializable

@Serializable
data class IdeaRow(
    val id: String,
    val user_id: String,
    val title: String,
    val raw_idea: String,
    val category: String = "Aplikasi",
    val goal: String = "",
    val target_users: String = "",
    val features: String = "",
    val platform: String = "",
    val expected_output: String = "",
    val status: String = "draft",
    val created_at: String? = null,
    val updated_at: String? = null
)

@Serializable
data class IdeaInsert(
    val user_id: String,
    val title: String,
    val raw_idea: String,
    val category: String = "Aplikasi"
)

@Serializable
data class IdeaUpdate(
    val title: String,
    val raw_idea: String,
    val category: String,
    val goal: String,
    val target_users: String,
    val features: String,
    val platform: String,
    val expected_output: String,
    val status: String
)

@Serializable
data class PromptVersionInsert(
    val project_id: String,
    val user_id: String,
    val mode: String,
    val prompt: String
)

@Serializable
data class ClarificationMessageInsert(
    val project_id: String,
    val user_id: String,
    val role: String,
    val content: String
)

fun IdeaRow.toIdea() = Idea(
    id = id,
    title = title,
    raw = raw_idea,
    category = category,
    goal = goal,
    target = target_users,
    features = features,
    platform = platform,
    output = expected_output,
    status = status
)

class IdeaRepository {
    private suspend fun userId(): String = supabase.auth.currentUserOrNull()?.id
        ?: error("Silakan login terlebih dahulu.")

    suspend fun list(): List<IdeaRow> = supabase.from("idea_projects")
        .select { order("updated_at", Order.DESCENDING) }
        .decodeList()

    suspend fun create(title: String, raw: String, category: String): IdeaRow {
        val row = IdeaInsert(userId(), title, raw, category)
        return supabase.from("idea_projects").insert(row) { select() }.decodeSingle()
    }

    suspend fun update(idea: Idea): IdeaRow {
        val patch = IdeaUpdate(
            idea.title, idea.raw, idea.category, idea.goal, idea.target,
            idea.features, idea.platform, idea.output, idea.status.lowercase()
        )
        return supabase.from("idea_projects").update(patch) {
            select()
            filter { eq("id", idea.id) }
        }.decodeSingle()
    }

    suspend fun delete(id: String) {
        supabase.from("idea_projects").delete { filter { eq("id", id) } }
    }

    suspend fun saveMessage(projectId: String, role: String, content: String) {
        supabase.from("idea_clarification_messages").insert(
            ClarificationMessageInsert(projectId, userId(), role, content)
        )
    }

    suspend fun savePrompt(projectId: String, mode: String, prompt: String) {
        supabase.from("idea_prompt_versions").insert(
            PromptVersionInsert(projectId, userId(), mode, prompt)
        )
    }
}
