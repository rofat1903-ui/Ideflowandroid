package com.ideflow.app

import io.github.jan.supabase.functions.invoke
import io.ktor.client.call.body
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

@Serializable
data class Blueprint(
    val title: String = "",
    val goal: String = "",
    val target_users: String = "",
    val platform: String = "Android",
    val features: List<String> = emptyList(),
    val expected_output: String = "",
    val assumptions: List<String> = emptyList()
)

@Serializable
data class ClarifyResponse(
    val action: String,
    val questions: List<String> = emptyList(),
    val blueprint: Blueprint? = null,
    val error: String? = null
)

@Serializable
data class PromptResponse(
    val mode: String,
    val prompt: String,
    val error: String? = null
)

class AiService {
    suspend fun clarify(idea: Idea, history: List<String>): ClarifyResponse {
        val historyJson = buildJsonArray { history.forEach { add(it) } }
        val body = buildJsonObject {
            put("action", "clarify")
            put("idea", buildJsonObject {
                put("title", idea.title)
                put("raw_idea", idea.raw)
                put("category", idea.category)
                put("goal", idea.goal)
                put("target_users", idea.target)
                put("features", idea.features)
                put("platform", idea.platform)
                put("expected_output", idea.output)
            })
            put("history", historyJson)
        }
        return supabase.functions.invoke("ideaflow-ai", body = body).body()
    }

    suspend fun prompt(idea: Idea, mode: String): PromptResponse {
        val body = buildJsonObject {
            put("action", "prompt")
            put("mode", mode.lowercase())
            put("idea", buildJsonObject { put("raw_idea", idea.raw) })
            put("blueprint", buildJsonObject {
                put("title", idea.title)
                put("goal", idea.goal)
                put("target_users", idea.target)
                put("platform", idea.platform)
                put("features", idea.features)
                put("expected_output", idea.output)
            })
        }
        return supabase.functions.invoke("ideaflow-ai", body = body).body()
    }
}
