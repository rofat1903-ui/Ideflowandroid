package com.ideflow.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.jan.supabase.auth.providers.Email
import kotlinx.coroutines.launch


data class Idea(
    val id: String,
    val title: String,
    val raw: String,
    val category: String,
    val goal: String = "",
    val target: String = "",
    val features: String = "",
    val platform: String = "",
    val output: String = "",
    val status: String = "draft"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { IdeaFlowRoot() } }
    }
}

@Composable
fun IdeaFlowRoot() {
    val scope = rememberCoroutineScope()
    val repo = remember { IdeaRepository() }
    val ai = remember { AiService() }
    var loading by remember { mutableStateOf(true) }
    var loggedIn by remember { mutableStateOf(false) }
    var ideas by remember { mutableStateOf<List<Idea>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        loading = true
        error = null
        try { ideas = repo.list().map { it.toIdea() } }
        catch (e: Exception) { error = e.message ?: "Gagal memuat data." }
        finally { loading = false }
    }

    LaunchedEffect(Unit) {
        loggedIn = supabase.auth.currentUserOrNull() != null
        if (loggedIn) refresh() else loading = false
    }

    if (!loggedIn) {
        AuthScreen(
            loading = loading,
            onLogin = { email, password ->
                scope.launch {
                    loading = true; error = null
                    try {
                        supabase.auth.signInWith(Email) { this.email = email; this.password = password }
                        loggedIn = true
                        refresh()
                    } catch (e: Exception) { error = e.message ?: "Login gagal."; loading = false }
                }
            },
            onRegister = { email, password ->
                scope.launch {
                    loading = true; error = null
                    try {
                        supabase.auth.signUpWith(Email) { this.email = email; this.password = password }
                        error = "Akun dibuat. Jika verifikasi email aktif, cek email lalu login."
                        loading = false
                    } catch (e: Exception) { error = e.message ?: "Pendaftaran gagal."; loading = false }
                }
            },
            error = error
        )
        return
    }

    var screen by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<Idea?>(null) }
    var search by remember { mutableStateOf("") }

    fun openIdea(idea: Idea) { selected = idea; screen = "detail" }
    fun updateLocal(idea: Idea) { ideas = ideas.map { if (it.id == idea.id) idea else it }; selected = idea }

    if (loading) { Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }; return }
    if (error != null) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text(error!!); Spacer(Modifier.height(12.dp)); Button({ error = null; scope.launch { refresh() } }) { Text("Coba lagi") }
        }
        return
    }

    when (screen) {
        "home" -> HomeScreen(ideas, search, { search = it }, { screen = "new" }, ::openIdea,
            onDelete = { id -> scope.launch { repo.delete(id); ideas = ideas.filterNot { it.id == id } } },
            onLogout = { scope.launch { supabase.auth.signOut(); loggedIn = false; ideas = emptyList() } })
        "new" -> NewIdeaScreen({ screen = "home" }) { title, raw, cat ->
            scope.launch {
                try { val created = repo.create(title, raw, cat).toIdea(); ideas = listOf(created) + ideas; selected = created; screen = "clarify" }
                catch (e: Exception) { error = e.message ?: "Gagal menyimpan ide." }
            }
        }
        "clarify" -> {
            val x = selected ?: run { screen = "home"; return }
            ClarifyScreen(x, ai, repo, { screen = "detail" }, ::updateLocal)
        }
        "detail" -> {
            val x = selected ?: run { screen = "home"; return }
            DetailScreen(x, { screen = "home" }, { screen = "clarify" }, { screen = "prompt" })
        }
        "prompt" -> {
            val x = selected ?: run { screen = "home"; return }
            PromptScreen(x, ai, repo, { screen = "detail" })
        }
    }
}

@Composable
fun AuthScreen(loading: Boolean, onLogin: (String, String) -> Unit, onRegister: (String, String) -> Unit, error: String?) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("IDE FLOW", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Simpan ide dan ubah menjadi prompt AI siap pakai.", Modifier.padding(top = 6.dp, bottom = 20.dp))
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") })
        Spacer(Modifier.height(16.dp))
        if (error != null) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 10.dp))
        Button({ onLogin(email.trim(), password) }, Modifier.fillMaxWidth(), enabled = !loading && email.isNotBlank() && password.length >= 6) { Text("LOGIN") }
        OutlinedButton({ onRegister(email.trim(), password) }, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !loading && email.isNotBlank() && password.length >= 6) { Text("BUAT AKUN") }
        if (loading) CircularProgressIndicator(Modifier.padding(top = 16.dp))
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        if (onBack != null) TextButton(onClick = onBack) { Text("← Kembali") }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (onBack == null) Spacer(Modifier.width(40.dp))
    }
}

@Composable
fun HomeScreen(ideas: List<Idea>, search: String, onSearch: (String) -> Unit, onNew: () -> Unit, onOpen: (Idea) -> Unit, onDelete: (String) -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("IDE FLOW", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); TextButton(onLogout) { Text("Keluar") } }
        Text("Ubah ide mentah menjadi prompt siap pakai.", Modifier.padding(horizontal = 16.dp))
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth().padding(16.dp), label = { Text("Cari ide...") })
        Button(onNew, Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Text("+ IDE BARU") }
        LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
            items(ideas.filter { it.title.contains(search, true) || it.raw.contains(search, true) }, key = { it.id }) { idea ->
                Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) { Column(Modifier.padding(16.dp)) {
                    Text(idea.title, fontWeight = FontWeight.Bold); Text("${idea.category} • ${idea.status}"); Text(idea.raw, maxLines = 2)
                    Row { TextButton({ onOpen(idea) }) { Text("Buka") }; TextButton({ onDelete(idea.id) }) { Text("Hapus") } }
                } }
            }
        }
    }
}

@Composable
fun NewIdeaScreen(onBack: () -> Unit, onSave: (String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }; var raw by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("Aplikasi") }
    Column(Modifier.fillMaxSize()) { Header("Ide Baru", onBack); Column(Modifier.padding(16.dp)) {
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Judul ide") }); Spacer(Modifier.height(10.dp))
        OutlinedTextField(raw, { raw = it }, Modifier.fillMaxWidth().height(180.dp), label = { Text("Tulis ide mentah") }); Spacer(Modifier.height(10.dp))
        OutlinedTextField(cat, { cat = it }, Modifier.fillMaxWidth(), label = { Text("Kategori") }); Spacer(Modifier.height(18.dp))
        Button({ if (title.isNotBlank() && raw.isNotBlank()) onSave(title, raw, cat) }, Modifier.fillMaxWidth()) { Text("PERJELAS DENGAN AI →") }
    } }
}

@Composable
fun ClarifyScreen(idea: Idea, ai: AiService, repo: IdeaRepository, onDone: () -> Unit, onUpdated: (Idea) -> Unit) {
    val scope = rememberCoroutineScope(); var loading by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    var questions by remember { mutableStateOf<List<String>>(emptyList()) }; var answers by remember { mutableStateOf<List<String>>(emptyList()) }; var history by remember { mutableStateOf<List<String>>(emptyList()) }
    var updated by remember { mutableStateOf(idea) }

    fun runClarify(nextHistory: List<String>) { scope.launch { loading = true; error = null; try {
        val r = ai.clarify(updated, nextHistory)
        if (r.action == "ask" && r.questions.isNotEmpty()) { questions = r.questions; answers = List(r.questions.size) { "" } }
        else if (r.blueprint != null) {
            val b = r.blueprint
            updated = updated.copy(title = b.title.ifBlank { updated.title }, goal = b.goal, target = b.target_users, features = b.features.joinToString("\n• ", prefix = if (b.features.isNotEmpty()) "• " else ""), platform = b.platform, output = b.expected_output, status = "clarified")
            repo.update(updated); onUpdated(updated); onDone()
        }
        history = nextHistory
    } catch (e: Exception) { error = e.message ?: "AI gagal memproses ide." } finally { loading = false } } }

    LaunchedEffect(Unit) { runClarify(emptyList()) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) { item {
        Header("AI Clarifier", onDone); Text("IDE MENTAH", fontWeight = FontWeight.Bold); Text(updated.raw, Modifier.padding(vertical = 8.dp))
        Text("AI akan bertanya hanya jika ada informasi penting yang belum jelas.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 14.dp))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 10.dp)) }
        questions.forEachIndexed { i, q ->
            Text(q, fontWeight = FontWeight.SemiBold); OutlinedTextField(answers.getOrElse(i) { "" }, { v -> answers = answers.toMutableList().also { it[i] = v } }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }
        if (questions.isNotEmpty()) Button({ val newHistory = history + questions.mapIndexed { i, q -> "Q: $q\nA: ${answers.getOrElse(i) { "" }}" }; runClarify(newHistory) }, Modifier.fillMaxWidth(), enabled = !loading) { Text("JAWAB & LANJUTKAN") }
        if (loading) CircularProgressIndicator(Modifier.padding(top = 16.dp))
    } }
}

@Composable
fun DetailScreen(idea: Idea, onBack: () -> Unit, onClarify: () -> Unit, onPrompt: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) { item { Header("Ide Final", onBack); Text(idea.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("${idea.category} • ${idea.status}"); Spacer(Modifier.height(14.dp))
        Section("Ide Mentah", idea.raw); Section("Tujuan", idea.goal); Section("Target Pengguna", idea.target); Section("Fitur", idea.features); Section("Platform", idea.platform); Section("Output", idea.output)
        OutlinedButton(onClarify, Modifier.fillMaxWidth()) { Text("EDIT / PERJELAS LAGI") }; Button(onPrompt, Modifier.fillMaxWidth()) { Text("BUAT PROMPT DENGAN AI") }
    } }
}

@Composable fun Section(label: String, value: String) { Text(label, fontWeight = FontWeight.Bold); Text(value.ifBlank { "-" }, Modifier.padding(bottom = 12.dp)) }

@Composable
fun PromptScreen(idea: Idea, ai: AiService, repo: IdeaRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope(); val clipboard = LocalClipboardManager.current
    var mode by remember { mutableStateOf("short") }; var prompt by remember { mutableStateOf("") }; var loading by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    fun generate(m: String) { scope.launch { loading = true; error = null; try { prompt = ai.prompt(idea, m).prompt; repo.savePrompt(idea.id, m, prompt) } catch (e: Exception) { error = e.message ?: "Gagal membuat prompt." } finally { loading = false } } }
    LaunchedEffect(Unit) { generate(mode) }
    Column(Modifier.fillMaxSize()) { Header("Prompt Generator", onBack); Row(Modifier.padding(horizontal = 16.dp)) { listOf("short", "detail", "master").forEach { m -> FilterChip(selected = mode == m, onClick = { mode = m; generate(m) }, label = { Text(m.replaceFirstChar { it.uppercase() }) }, Modifier.padding(end = 6.dp)) } }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth().weight(1f).padding(16.dp), label = { Text("Prompt siap pakai") })
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Button({ clipboard.setText(AnnotatedString(prompt)) }, Modifier.fillMaxWidth().padding(16.dp), enabled = prompt.isNotBlank()) { Text("COPY PROMPT") }
    }
}
