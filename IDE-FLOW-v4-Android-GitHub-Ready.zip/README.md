# IDE FLOW v2 — Android + Supabase AI

IDE FLOW mengubah ide mentah menjadi blueprint yang jelas lalu prompt AI siap copy.

## Alur
1. Login / buat akun Supabase.
2. Tulis ide mentah.
3. AI Clarifier menganalisis ide.
4. Jika informasi penting belum jelas, AI hanya mengajukan pertanyaan yang diperlukan.
5. Jawaban diproses sampai menjadi Blueprint.
6. Blueprint disimpan ke Supabase.
7. Prompt Generator membuat mode Short, Detail, atau Master.
8. Prompt disimpan sebagai versi dan bisa langsung dicopy.

## Backend yang digunakan
Project Supabase: `Rofat`
Project ref: `coefkqzjjefoyarpqzzm`
Edge Function: `ideaflow-ai` (JWT verification aktif)

Tabel:
- `idea_projects`
- `idea_clarification_messages`
- `idea_prompt_versions`

RLS membatasi data berdasarkan `auth.uid() = user_id`.

## Keamanan
APK hanya menggunakan Supabase Publishable Key. Jangan pernah memasukkan `service_role`, secret key, atau `OPENAI_API_KEY` ke Android.
`OPENAI_API_KEY` tetap berada di Supabase Edge Function Secrets.

## Android
Disarankan membuka project dengan Android Studio dan melakukan Gradle Sync.
Minimum SDK 26.

Supabase Kotlin mengikuti dokumentasi `supabase-kt` terbaru yang digunakan saat project ini dibuat.

Catatan: environment build di workspace ini tidak memiliki Android SDK/Gradle wrapper, sehingga APK binary belum dibuild di sini. Source project sudah disiapkan untuk Sync/Build di Android Studio.

## Jika Auth meminta verifikasi email
Itu mengikuti pengaturan Confirm email pada Supabase Auth. Setelah email dikonfirmasi, login kembali.

## Status
Phase ini menargetkan koneksi nyata Android → Supabase Auth → Database → Edge Function AI → Database.
Fitur tambahan seperti sinkronisasi offline penuh, history UI, export/import, dan multi-provider AI sengaja belum ditambahkan agar workflow inti tetap sederhana.
